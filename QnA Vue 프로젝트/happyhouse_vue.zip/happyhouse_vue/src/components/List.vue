<template>
  <div>
    <h4 class="text-center">게시글 목록</h4>
    <div class="text-right">
      <div class="form-group">
        <label for="sel1">Select list:</label>
        <select class="form-control" id="sel1" v-model="key">
          <option disabled value="">선택</option>
          <option value="title">제목</option>
          <option value="userid">작성자</option>
        </select>
        <input
          type="text"
          class="form-control"
          placeholder="검색어 입력"
          v-model="word"
          v-on:keyup.enter="search"
        />
        <div class="input-group-append">
          <button class="btn btn-info" type="button" @click="search">검색</button>
        </div>
      </div>
      <button class="btn btn-primary" @click="mvregist">등록</button>
    </div>
    <div v-if="Qnas.length > 0">
      <table class="table table-boardered table-condensed">
        <colgroup>
          <col width="10%" />
          <col width="50%" />
          <col width="15%" />
          <col width="25%" />
        </colgroup>
        <tr>
          <th>번호</th>
          <th>제목</th>
          <th>작성자</th>
          <th>날짜</th>
          <th>답변 여부</th>
        </tr>
        <tr v-for="(qna, index) in Qnas" :key="index">
          <td>{{ qna.no }}</td>
          <td>
            <router-link :to="'qna/search?no=' + qna.no">{{ qna.title }}</router-link>
          </td>
          <td v-text="qna.userid"></td>
          <td>{{ qna.regdate | toDate }}</td>
          <td v-if="qna.repl" class="text-success">답변 완료</td>
          <td v-else class="text-light">미답변</td>
        </tr>
      </table>
    </div>
    <div v-else class="text-danger">등록된 QnA가 없습니다.</div>
  </div>
</template>
<script>
import moment from "moment";
import { mapGetters } from "vuex";
export default {
  name: "QnA",
  data() {
    return {
      key: "",
      word: "",
    };
  },
  filters: {
    toDate(regdate) {
      return moment(new Date(regdate)).format("YYYY.MM.DD");
    },
  },
  computed: {
    ...mapGetters(["Qnas"]),
  },
  created() {
    this.searchAll();
  },
  methods: {
    mvregist() {
      this.$router.push("qna/create");
    },
    search() {
      // 검색할 결과를 담을 배열

      // 만약 검색어가 없을 때
      if (!this.word || this.word == "") {
        this.searchAll();
      } else {
        // 검색어가 있다면
        this.$store.dispatch(
          "getQnas",
          `http://localhost/qna.do?key=${this.key}&word=${this.word}`
        );
      }
    },
    searchAll() {
      this.$store.dispatch("getQnas", `http://localhost/qna.do/`);
    },
  },
};
</script>
