<template>
  <div class="container">
    <h2 class="text-center">Vue를 이용한 게시판</h2>
    <table class="table table-condensed w-25 text-center" v-if="Qna">
      <tr>
        <th>제목</th>
        <td v-text="Qna.title"></td>
      </tr>
      <tr>
        <th>작성자</th>
        <td v-text="Qna.userid"></td>
      </tr>
      <tr>
        <th>작성일</th>
        <td>{{ Qna.regdate | toDate }}</td>
      </tr>
      <tr style="height: 100px">
        <th>내용</th>
        <td v-text="Qna.contents"></td>
      </tr>
      <tr style="height: 100px" v-if="Qna.repl">
        <th>답변</th>
        <td v-text="Qna.repl"></td>
      </tr>
      <tr style="height: 100px" v-else-if="!Qna.repl && Qna.loginId != 'admin'">
        <th>답변</th>
        <td class="text-danger">등록된 답변이 없습니다!</td>
      </tr>
      <tr style="height: 100px" v-else-if="!Qna.repl && Qna.loginId == 'admin'">
        <th>답변</th>
        <td>
          <textarea cols="30" rows="10" ref="re" v-model="reply"></textarea>
          <button class="btn btn-primary" @click="registRe">등록</button>
        </td>
      </tr>
    </table>
    <div class="text-right">
      <router-link class="btn btn-primary" to="/">목록</router-link>
      <button
        class="btn btn-primary"
        @click="update()"
        v-if="Qna.userid == Qna.loginid && !Qna.repl"
      >
        수정
      </button>
      <button class="btn btn-primary" @click="remove()" v-if="Qna.userid == Qna.loginId">
        삭제
      </button>
    </div>
  </div>
</template>
<script>
import axios from "axios";
import { mapGetters } from "vuex";
import moment from "moment";
export default {
  data() {
    return {
      reply: "",
    };
  },
  filters: {
    toDate(regdate) {
      return moment(new Date(regdate)).format("YYYY.MM.DD");
    },
  },
  computed: {
    ...mapGetters(["Qna"]),
  },
  created() {
    this.$store.dispatch("getQna", `http://localhost/qna.do/${this.$route.query.no}`);
  },
  methods: {
    update() {
      this.$router.push("/update");
    },
    remove() {
      this.$router.push("/remove");
    },
    registRe() {
      if (!this.reply) {
        alert("답변을 입력하세요");
        this.$refs.re.focus();
      } else {
        axios
          .put(`http://localhost/qna/${this.$store.Getters.Qna.no}`, {
            title: this.$store.Getters.Qna.title,
            userid: this.$store.Getters.Qna.userid,
            content: this.$store.Getters.Qna.contents,
            reply: this.reply,
          })
          .then(({ data }) => {
            if (data == "success") {
              alert("수정 완료!!");
              this.moveHandler();
            } else {
              alert("수정 중 오류 발생!");
            }
          })
          .catch((err) => {
            console.log(err);
            alert("오류 발생!!");
          });
      }
    },
  },
};
</script>
