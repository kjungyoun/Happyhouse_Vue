<template>
  <div>
    <h2 class="text-center">QnA 수정</h2>
    <table class="table table-condensed w-25">
      <tr>
        <th>제목</th>
        <td>
          <input
            type="text"
            id="title"
            placeholder="제목을 입력해주세요"
            ref="title"
            v-model="Qna.title"
          />
        </td>
      </tr>
      <tr>
        <th>내용</th>
        <td>
          <textarea
            id="content"
            cols="30"
            rows="10"
            ref="content"
            v-model="Qna.contents"
          ></textarea>
        </td>
      </tr>
    </table>
    <div class="text-right">
      <button class="btn btn-primary" @click="updateHandler">수정</button>
      <button class="btn btn-primary" @click="moveHandler">목록</button>
    </div>
  </div>
</template>
<script>
import axios from "axios";
import { mapGetters } from "vuex";
export default {
  name: "Update",
  computed: {
    ...mapGetters(["Qna"]),
  },
  methods: {
    updateHandler() {
      let err = true;
      let msg = "";
      !this.Qna.title && ((err = false), (msg = "제목을 입력해주세요"), this.$refs.title.focus());
      err &&
        !this.Qna.contents &&
        ((err = false), (msg = "내용을 입력해주세요"), this.$refs.content.focus());

      if (!err) {
        console.log(err);
        alert(msg);
      } else {
        //데이터 변경
        axios
          .put(`http://localhost/qna.do/${this.Qna.no}`, {
            no: this.Qna.no,
            title: this.Qna.title,
            userid: this.Qna.loginid,
            contents: this.Qna.contents,
          })
          .then(({ data }) => {
            if (data == 1) {
              alert("수정 완료!!");
              this.moveHandler();
            } else {
              alert("수정 중 오류 발생!");
            }
          })
          .catch((err) => {
            console.log(err);
            alert("오류 발생!!");
          });
      }
    },
    moveHandler() {
      this.$router.push("/");
    },
  },
};
</script>
