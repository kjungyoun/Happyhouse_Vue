<template>
  <div>삭제중 ...</div>
</template>
<script>
import axios from "axios";
import { mapGetters } from "vuex";
export default {
  name: "Remove",
  computed: {
    ...mapGetters(["Qna"]),
  },
  created() {
    this.removeBoard(this.Qna.no);
  },
  methods: {
    removeBoard(no) {
      axios
        .delete(`http://localhost/qna.do/${no}`)
        .then(({ data }) => {
          if (data == 1) {
            alert("삭제완료");
            this.$router.push("/");
          } else {
            alert("삭제중 오류 발생");
            this.$router.push(`/search?no=${no}`);
          }
        })
        .catch((err) => {
          console.log(err);
          alert("오류발생!");
          this.$router.push(`/search?no=${no}`);
        });
    },
  },
};
</script>
