import Vue from "vue";
import Vuex from "vuex";
import axios from "axios";

Vue.use(Vuex);

export default new Vuex.Store({
  state: {
    qnas: [],
    qna: {},
    loginId: String,
  },
  getters: {
    Qnas(state) {
      return state.qnas;
    },
    Qna(state) {
      return state.qna;
    },
    loginId(state) {
      return state.loginId;
    },
  },
  mutations: {
    SET_QNAS(state, payload) {
      state.qnas = payload;
    },
    SET_QNA(state, payload) {
      state.qna = payload;
    },
    SET_LOGIN_ID(state, payload) {
      state.loginId = payload;
    },
  },
  actions: {
    getQnas({ commit }, payload) {
      axios
        .get(payload)
        .then(({ data }) => {
          commit("SET_QNAS", data);
        })
        .catch(() => {
          alert("qna 리스트 조회중 오류 발생!");
        });
    },
    getQna({ commit }, payload) {
      axios
        .get(payload)
        .then(({ data }) => {
          commit("SET_QNA", data);
        })
        .catch(() => {
          alert("qna 상세 조회중 오류 발생");
        });
    },
    getLoginId({ commit }) {
      axios
        .get("http://localhost/qna.do/getLoginId")
        .then(({ data }) => {
          commit("SET_LOGIN_ID", data);
        })
        .catch(() => {
          alert("로그인 아이디 조회 중 오류 발생");
        });
    },
  },
});
